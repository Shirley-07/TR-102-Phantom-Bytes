import { FishingZone } from "./types";

export const FISHING_ZONES: FishingZone[] = [
  { id: 'chennai', name: 'Chennai Harbor', lat: 13.0827, lon: 80.2707, state: 'Tamil Nadu' },
  { id: 'nagapattinam', name: 'Nagapattinam Port', lat: 10.7661, lon: 79.8444, state: 'Tamil Nadu' },
  { id: 'rameshwaram', name: 'Rameswaram Jetty', lat: 9.2876, lon: 79.3129, state: 'Tamil Nadu' },
  { id: 'tuticorin', name: 'Tuticorin Port', lat: 8.7642, lon: 78.1348, state: 'Tamil Nadu' },
  { id: 'kanyakumari', name: 'Kanyakumari Coast', lat: 8.0883, lon: 77.5385, state: 'Tamil Nadu' },
  { id: 'kochi', name: 'Kochi Harbor', lat: 9.9312, lon: 76.2673, state: 'Kerala' },
  { id: 'vizag', name: 'Visakhapatnam Port', lat: 17.6868, lon: 83.2185, state: 'Andhra Pradesh' },
  { id: 'puri', name: 'Puri Beach', lat: 19.8135, lon: 85.8312, state: 'Odisha' },
  { id: 'veraval', name: 'Veraval Port', lat: 20.9000, lon: 70.3700, state: 'Gujarat' },
  { id: 'mumbai', name: 'Sassoon Dock', lat: 18.9167, lon: 72.8167, state: 'Maharashtra' },
];

export const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'ta', name: 'தமிழ் (Tamil)' },
  { code: 'ml', name: 'മലയാളം (Malayalam)' },
  { code: 'te', name: 'తెలుగు (Telugu)' },
  { code: 'or', name: 'ଓଡ଼ିଆ (Odia)' },
  { code: 'hi', name: 'हिन्दी (Hindi)' },
];
