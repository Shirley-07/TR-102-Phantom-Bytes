import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Clock, MapPin, Shield, ChevronRight, History as HistoryIcon, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';

interface SafetyReport {
  id: string;
  zoneId: string;
  zoneName: string;
  score: number;
  level: string;
  recommendation: string;
  reasoning: string[];
  safeReturnTime: string;
  confidence: number;
  createdAt: string;
}

interface HistoryViewProps {
  token: string | null;
}

export default function HistoryView({ token }: HistoryViewProps) {
  const [reports, setReports] = useState<SafetyReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;

    const fetchHistory = async () => {
      try {
        const response = await fetch('/api/safety-reports', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) throw new Error('Failed to fetch history');
        const data = await response.json();
        setReports(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistory();
  }, [token]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <div className="w-12 h-12 border-4 border-accent-blue/20 border-t-accent-blue animate-spin rounded-full" />
        <p className="text-white/40 text-sm font-bold uppercase tracking-widest">Retrieving Sea Logs...</p>
      </div>
    );
  }

  if (reports.length === 0) {
    return (
      <div className="glass p-12 rounded-[32px] text-center border border-white/10">
        <div className="w-16 h-16 bg-white/5 flex items-center justify-center rounded-2xl mx-auto mb-6">
          <HistoryIcon className="w-8 h-8 text-white/20" />
        </div>
        <h3 className="text-xl font-bold mb-2">No Reports Found</h3>
        <p className="text-white/40 max-w-xs mx-auto text-sm">Your safety assessments will appear here once you start checking zones.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <HistoryIcon className="w-6 h-6 text-accent-blue" />
          <h2 className="text-2xl font-black uppercase tracking-tight italic">Safety <span className="text-accent-blue">History</span></h2>
        </div>
        <div className="px-3 py-1 bg-white/5 rounded-full border border-white/10">
          <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Last 10 Reports</span>
        </div>
      </div>

      <div className="space-y-4">
        {reports.map((report, idx) => (
          <motion.div
            key={report.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="glass p-6 rounded-[24px] border border-white/10 hover:border-white/20 transition-all group"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border",
                  report.level === 'SAFE' && "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
                  report.level === 'CAUTION' && "bg-amber-500/10 border-amber-500/20 text-amber-400",
                  report.level === 'DANGER' && "bg-rose-500/10 border-rose-500/20 text-rose-400"
                )}>
                  <span className="text-lg font-black">{report.score}</span>
                </div>
                
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <MapPin className="w-3.5 h-3.5 text-accent-blue" />
                    <h4 className="font-bold text-lg leading-none">{report.zoneName}</h4>
                  </div>
                  <div className="flex items-center gap-4 text-white/40 text-[10px] font-bold uppercase tracking-wider">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(report.createdAt), 'MMM dd, yyyy')}
                    </div>
                    <div className="flex items-center gap-1.5" title="Indian Standard Time">
                      <Clock className="w-3 h-3 text-accent-blue" />
                      {new Intl.DateTimeFormat('en-IN', {
                        timeZone: 'Asia/Kolkata',
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: false
                      }).format(new Date(report.createdAt))} 
                      <span className="opacity-50 lowercase tracking-tighter">IST</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 md:justify-end">
                <div className={cn(
                   "px-3 py-1 rounded-full text-[10px] font-black tracking-tighter",
                   report.level === 'SAFE' && "bg-emerald-500/10 text-emerald-400",
                   report.level === 'CAUTION' && "bg-amber-500/10 text-amber-400",
                   report.level === 'DANGER' && "bg-rose-500/10 text-rose-400"
                )}>
                  {report.level}
                </div>
                <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] font-bold text-white/60 tracking-tighter flex items-center gap-1.5">
                   <Shield className="w-3 h-3" />
                   {report.confidence}% Conf.
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-white/5">
              <p className="text-white/60 text-sm italic line-clamp-2group-hover:line-clamp-none transition-all">
                "{report.recommendation}"
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
