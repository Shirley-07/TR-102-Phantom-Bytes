import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, AlertTriangle, XCircle, CloudLightning, Clock, Shield } from 'lucide-react';
import { SafetyScore } from '../types';
import { cn } from '../lib/utils';

interface SafetyScoreCardProps {
  score: SafetyScore;
}

export default function SafetyScoreCard({ score }: SafetyScoreCardProps) {
  const getLevelConfig = () => {
    switch (score.level) {
      case 'SAFE':
        return { icon: CheckCircle2, color: 'text-success-green', bg: 'bg-success-green', border: 'border-success-green/30', label: 'SAFE' };
      case 'ADVISORY':
        return { icon: AlertTriangle, color: 'text-warning-orange', bg: 'bg-warning-orange', border: 'border-warning-orange/30', label: 'ADVISORY' };
      case 'DANGER':
        return { icon: XCircle, color: 'text-danger-red', bg: 'bg-danger-red', border: 'border-danger-red/30', label: 'DANGER' };
      case 'CYCLONE':
        return { icon: CloudLightning, color: 'text-purple-400', bg: 'bg-purple-500', border: 'border-purple-500/30', label: 'CYCLONE' };
      default:
        return { icon: CheckCircle2, color: 'text-success-green', bg: 'bg-success-green', border: 'border-success-green/30', label: 'SAFE' };
    }
  };

  const config = getLevelConfig();

  return (
    <div className="flex flex-col gap-6">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-linear-to-br from-[#1e293b] to-[#0f172a] p-8 rounded-[24px] border border-white/15 flex flex-col md:flex-row items-center gap-10 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-48 h-full bg-linear-to-r from-transparent to-accent-blue/5 pointer-events-none" />
        
        {/* Risk Gauge */}
        <div className="relative w-36 h-36 rounded-full border-[10px] border-[#1e293b] flex flex-col items-center justify-center shrink-0"
             style={{ borderTopColor: score.level === 'SAFE' ? '#00e676' : score.level === 'ADVISORY' ? '#ff9f00' : '#ff3e3e' }}>
          <span className="text-[10px] uppercase font-bold tracking-widest text-text-dim">AI Risk</span>
          <span className={cn("text-4xl font-black", config.color)}>{score.score}</span>
          <span className="text-[10px] uppercase font-bold tracking-widest text-text-dim">{config.label}</span>
        </div>

        <div className="flex-1 text-center md:text-left">
          <div className={cn("inline-block px-3 py-1 rounded text-white font-bold text-sm mb-3 uppercase tracking-wider", config.bg)}>
            {score.level}: {score.level === 'CYCLONE' ? 'SEVERE ALERT' : 'ADVISORY'}
          </div>
          <h2 className="text-3xl font-bold mb-2 tracking-tight">{score.recommendation}</h2>
          <p className="text-text-dim text-lg leading-relaxed max-w-xl">
            {score.reasoning.join(". ")}
          </p>

          <div className="mt-6 flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
            <div className="bg-accent-blue/20 p-2.5 rounded-xl">
              <Shield className="w-6 h-6 text-accent-blue animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-black tracking-widest text-accent-blue">Offline Safety Cache Enabled</p>
              <p className="text-xs text-white/60">This advice remains valid for the next 24 hours even without signal.</p>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="bg-[#0f172a] border border-white/15 rounded-[20px] p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <div className="text-[10px] uppercase font-bold tracking-widest text-text-dim mb-1">Best Safe Return Window</div>
          <div className="text-xl font-bold flex items-center gap-2">
            <Clock className="w-5 h-5 text-accent-blue" />
            {score.safeReturnTime}
          </div>
        </div>
        <div className="text-center sm:text-right">
          <div className="text-[10px] uppercase font-bold tracking-widest text-text-dim mb-1">Confidence Level</div>
          <div className="text-xl font-bold text-success-green">{score.confidence}%</div>
        </div>
      </div>
    </div>
  );
}
