import React from 'react';
import { Wind, Droplets, Eye, Waves, Thermometer, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { WeatherData } from '../types';
import { cn } from '../lib/utils';

interface WeatherCardProps {
  data: WeatherData;
}

export default function WeatherCard({ data }: WeatherCardProps) {
  const current = data.weather.current;
  const marine = data.marine.current;

  const stats = [
    { label: 'Wind Speed', value: current.wind_speed_10m, unit: 'KM/H', icon: Wind, color: 'text-accent-blue' },
    { label: 'Wave Height', value: marine.wave_height, unit: 'METERS', icon: Waves, color: 'text-accent-blue' },
    { label: 'Visibility', value: (current.visibility / 1000).toFixed(1), unit: 'KM', icon: Eye, color: 'text-accent-blue' },
    { label: 'Rain Chance', value: data.weather.daily.precipitation_probability_max[0], unit: '%', icon: Droplets, color: 'text-accent-blue' },
    { label: 'Temperature', value: current.temperature_2m, unit: '°C', icon: Thermometer, color: 'text-accent-blue' },
    { label: 'Wave Period', value: marine.wave_period, unit: 'SECONDS', icon: ArrowUpRight, color: 'text-accent-blue' },
  ];

  return (
    <div className="grid grid-cols-2 gap-4">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          className="bg-white/5 border border-white/15 p-5 rounded-[20px] text-center flex flex-col items-center justify-center gap-1"
        >
          <div className={cn("text-2xl mb-1", stat.color)}>
            <stat.icon className="w-6 h-6 mx-auto" />
          </div>
          <div className="text-2xl font-bold tracking-tight">{stat.value}</div>
          <div className="text-[10px] uppercase font-bold tracking-widest text-text-dim">{stat.label} ({stat.unit})</div>
        </motion.div>
      ))}
    </div>
  );
}
