import React from 'react';
import { Anchor, Bell, Map as MapIcon, Shield, Menu, WifiOff, Globe } from 'lucide-react';
import { cn } from '../lib/utils';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOffline?: boolean;
}

export default function Header({ activeTab, setActiveTab, isOffline = false }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-navy-dark/80 backdrop-blur-md border-b border-white/15 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-accent-blue text-2xl">⚓</div>
          <h1 className="font-bold text-xl tracking-tight uppercase">
            Fisherfolk <span className="text-accent-blue">AI</span>
          </h1>
        </div>

        <nav className="hidden md:flex items-center gap-2">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Shield },
            { id: 'map', label: 'Risk Map', icon: MapIcon },
            { id: 'alerts', label: 'Alerts', icon: Bell },
            { id: 'history', label: 'History', icon: Anchor },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-xl transition-all text-sm font-semibold",
                activeTab === item.id 
                  ? "bg-accent-blue text-navy-dark shadow-[0_0_15px_rgba(0,212,255,0.4)]" 
                  : "text-text-dim hover:bg-white/5 hover:text-white"
              )}
            >
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="hidden sm:flex items-center gap-4">
          <div className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest border",
            isOffline 
              ? "bg-amber-500/10 text-amber-400 border-amber-500/20" 
              : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
          )}>
            {isOffline ? (
              <><WifiOff className="w-3 h-3" /> Offline (Cache Mode)</>
            ) : (
              <><Globe className="w-3 h-3" /> Connected</>
            )}
          </div>

          <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full border border-white/15 text-sm font-medium">
            <span className="text-accent-blue">📍</span>
            <span className="font-bold">Active Zone</span>
            <span className="text-text-dim">| Monitoring</span>
          </div>
        </div>

        <button className="p-2 rounded-xl hover:bg-white/5 md:hidden">
          <Menu className="w-6 h-6" />
        </button>
      </div>
    </header>
  );
}
