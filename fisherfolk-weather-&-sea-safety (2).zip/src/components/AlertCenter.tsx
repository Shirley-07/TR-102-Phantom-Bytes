import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Volume2, VolumeX, Languages, Share2 } from 'lucide-react';
import { LANGUAGES } from '../constants';
import { cn } from '../lib/utils';

interface AlertCenterProps {
  alerts: any;
}

export default function AlertCenter({ alerts }: AlertCenterProps) {
  const [selectedLang, setSelectedLang] = useState('en');
  const [isSpeaking, setIsSpeaking] = useState(false);

  const stop = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const speak = (text: string) => {
    // Cancel any ongoing speech first
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    const langMap: any = {
      en: 'en-US',
      ta: 'ta-IN',
      ml: 'ml-IN',
      te: 'te-IN',
      hi: 'hi-IN',
    };
    utterance.lang = langMap[selectedLang] || 'en-US';
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="bg-white/5 border border-white/15 rounded-[24px] p-6 flex flex-col gap-6 h-full">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-accent-blue uppercase font-bold text-sm tracking-widest">
          <span>Emergency Alerts</span>
          <div className="w-2 h-2 rounded-full bg-danger-red animate-pulse" />
        </div>
        <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar max-w-[150px] sm:max-w-none">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              onClick={() => {
                setSelectedLang(lang.code);
                stop(); // Stop audio when switching language
              }}
              className={cn(
                "px-2 py-1 rounded-lg text-[10px] font-bold transition-all shrink-0 uppercase tracking-tighter",
                selectedLang === lang.code
                  ? "bg-accent-blue text-navy-dark"
                  : "bg-white/5 text-text-dim hover:bg-white/10"
              )}
            >
              {lang.code}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 space-y-6 overflow-y-auto pr-2 custom-scrollbar">
        <motion.div
          key={selectedLang}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="border-l-2 border-danger-red pl-4 py-1"
        >
          <div className="text-[10px] text-text-dim uppercase font-bold tracking-widest mb-1">
            {LANGUAGES.find(l => l.code === selectedLang)?.name}
          </div>
          <div className="text-sm leading-relaxed font-medium">
            {alerts[selectedLang]}
          </div>
        </motion.div>

        {/* Secondary Alert Example */}
        <div className="border-l-2 border-warning-orange pl-4 py-1">
          <div className="text-[10px] text-text-dim uppercase font-bold tracking-widest mb-1">
            General Safety
          </div>
          <div className="text-sm leading-relaxed font-medium">
            Severe weather alert. Avoid offshore activities. Return to harbor immediately.
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-white/10 flex gap-2">
        {!isSpeaking ? (
          <button 
            onClick={() => speak(alerts[selectedLang])}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors font-bold text-xs uppercase tracking-widest"
          >
            <Volume2 className="w-4 h-4 text-accent-blue" />
            Listen
          </button>
        ) : (
          <button 
            onClick={stop}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-danger-red/20 hover:bg-danger-red/30 text-danger-red transition-colors font-bold text-xs uppercase tracking-widest border border-danger-red/30"
          >
            <VolumeX className="w-4 h-4" />
            Stop
          </button>
        )}
        <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors font-bold text-xs uppercase tracking-widest">
          <Share2 className="w-4 h-4 text-accent-blue" />
          Share
        </button>
      </div>
    </div>
  );
}
