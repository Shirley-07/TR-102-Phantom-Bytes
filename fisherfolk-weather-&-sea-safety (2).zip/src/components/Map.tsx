import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { FishingZone, SafetyLevel } from '../types';
import { FISHING_ZONES } from '../constants';

// Fix for default marker icons in Leaflet with React
// @ts-ignore
import markerIcon from 'leaflet/dist/images/marker-icon.png';
// @ts-ignore
import markerIconRetina from 'leaflet/dist/images/marker-icon-2x.png';
// @ts-ignore
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconUrl: markerIcon,
  iconRetinaUrl: markerIconRetina,
  shadowUrl: markerShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapProps {
  center: [number, number];
  zones: FishingZone[];
  safetyLevel: SafetyLevel;
}

function ChangeView({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, 10);
  }, [center, map]);
  return null;
}

export default function Map({ center, zones, safetyLevel }: MapProps) {
  const getZoneColor = (level: SafetyLevel) => {
    switch (level) {
      case 'SAFE': return '#10b981';
      case 'ADVISORY': return '#f59e0b';
      case 'DANGER': return '#f43f5e';
      case 'CYCLONE': return '#a855f7';
      default: return '#10b981';
    }
  };

  return (
    <div className="h-[500px] w-full rounded-3xl overflow-hidden glass border-4 border-white/10">
      <MapContainer center={center} zoom={10} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <ChangeView center={center} />
        
        {FISHING_ZONES.map((zone) => (
          <React.Fragment key={zone.id}>
            <Marker position={[zone.lat, zone.lon]}>
              <Popup>
                <div className="p-2">
                  <h3 className="font-bold text-ocean-900">{zone.name}</h3>
                  <p className="text-xs text-ocean-700">{zone.state}</p>
                </div>
              </Popup>
            </Marker>
            <Circle
              center={[zone.lat, zone.lon]}
              radius={15000}
              pathOptions={{ 
                fillColor: zone.lat === center[0] ? getZoneColor(safetyLevel) : '#10b981',
                color: zone.lat === center[0] ? getZoneColor(safetyLevel) : '#10b981',
                fillOpacity: 0.2 
              }}
            />
          </React.Fragment>
        ))}
      </MapContainer>
    </div>
  );
}
