import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, Phone, MapPin, Navigation, RefreshCw } from 'lucide-react';

interface SOSButtonProps {
  onSOS: () => Promise<void>;
}

export default function SOSButton({ onSOS }: SOSButtonProps) {
  const [isConfirming, setIsConfirming] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSOS = async () => {
    if (!isConfirming) {
      setIsConfirming(true);
      return;
    }
    
    setIsLoading(true);
    await onSOS();
    setIsSent(true);
    setIsLoading(false);
    
    setTimeout(() => {
      setIsSent(false);
      setIsConfirming(false);
    }, 5000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      <AnimatePresence>
        {isConfirming && !isSent && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="absolute bottom-20 right-0 glass-dark p-6 rounded-3xl w-72 shadow-2xl border-2 border-rose-500/50"
          >
            <h3 className="text-xl font-black text-rose-400 mb-2">Confirm SOS?</h3>
            <p className="text-sm text-white/70 mb-6">
              This will send your GPS coordinates to the Coast Guard and your emergency contacts.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setIsConfirming(false)}
                className="flex-1 py-3 rounded-xl bg-white/10 font-bold hover:bg-white/20 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleSOS}
                disabled={isLoading}
                className="flex-1 py-3 rounded-xl bg-rose-600 font-bold hover:bg-rose-500 transition-colors shadow-lg shadow-rose-900/40 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'SEND'}
              </button>
            </div>
          </motion.div>
        )}

        {isSent && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="absolute bottom-20 right-0 glass p-6 rounded-3xl w-72 shadow-2xl border-2 border-emerald-500/50"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-emerald-500/20 p-2 rounded-lg">
                <Navigation className="w-6 h-6 text-emerald-400 animate-pulse" />
              </div>
              <h3 className="text-xl font-black text-emerald-400">SOS SENT</h3>
            </div>
            <p className="text-sm text-white/70">
              Help is on the way. Stay near your current location if safe.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleSOS}
        className={`w-full py-5 rounded-2xl flex items-center justify-center gap-3 shadow-2xl transition-all duration-300 font-extrabold text-lg uppercase tracking-widest ${
          isConfirming ? 'bg-rose-600 animate-pulse' : 'bg-danger-red'
        }`}
      >
        <span className="text-2xl">🆘</span>
        SEND SOS SIGNAL
      </motion.button>
    </div>
  );
}
