import React from 'react';
import { motion } from 'motion/react';
import { Anchor, Shield, Bell, Map as MapIcon, ArrowRight } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
}

export default function LandingPage({ onStart }: LandingPageProps) {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-navy-mid to-navy-dark" />
        <svg className="waves" xmlns="http://www.w3.org/2000/svg" viewBox="0 24 150 28" preserveAspectRatio="none" shapeRendering="auto">
          <defs>
            <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z" />
          </defs>
          <g className="parallax">
            <use xlinkHref="#gentle-wave" x="48" y="0" fill="rgba(0, 212, 255, 0.3)" />
            <use xlinkHref="#gentle-wave" x="48" y="3" fill="rgba(0, 212, 255, 0.2)" />
            <use xlinkHref="#gentle-wave" x="48" y="5" fill="rgba(0, 212, 255, 0.1)" />
            <use xlinkHref="#gentle-wave" x="48" y="7" fill="rgba(0, 212, 255, 0.5)" />
          </g>
        </svg>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 max-w-4xl w-full text-center"
      >
        <div className="inline-flex items-center gap-2 bg-white/5 backdrop-blur-md px-4 py-2 rounded-full border border-white/15 mb-8">
          <Anchor className="w-4 h-4 text-accent-blue" />
          <span className="text-xs font-bold uppercase tracking-widest text-text-dim">Coastal Safety Initiative</span>
        </div>

        <h1 className="text-5xl sm:text-7xl font-black tracking-tighter mb-6 leading-none uppercase">
          SEA SAFETY <br />
          <span className="text-accent-blue">REIMAGINED.</span>
        </h1>

        <p className="text-lg sm:text-xl text-text-dim mb-10 max-w-2xl mx-auto font-medium">
          Hyperlocal marine weather risk advisories for Indian coastal fisherfolk. 
          Decide with confidence. Return with safety.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button 
            onClick={onStart}
            className="group flex items-center justify-center gap-2 bg-accent-blue hover:bg-accent-blue/90 text-navy-dark px-8 py-4 rounded-2xl font-bold text-lg transition-all shadow-xl shadow-accent-blue/20"
          >
            Launch Dashboard
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
          <button className="flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white px-8 py-4 rounded-2xl font-bold text-lg transition-all border border-white/15">
            Learn More
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-left">
          {[
            { icon: Shield, title: 'AI Risk Score', desc: 'Real-time safety analysis using Gemini AI.' },
            { icon: Bell, title: 'Voice Alerts', desc: 'Multilingual warnings in your local tongue.' },
            { icon: MapIcon, title: 'Danger Zones', desc: 'Interactive maps showing coastal risks.' },
          ].map((feature, i) => (
            <div key={i} className="bg-white/5 border border-white/15 p-6 rounded-2xl">
              <feature.icon className="w-8 h-8 text-accent-blue mb-4" />
              <h3 className="font-bold text-lg mb-1">{feature.title}</h3>
              <p className="text-sm text-text-dim leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
