export interface WeatherData {
  marine: any;
  weather: any;
}

export interface FishingZone {
  id: string;
  name: string;
  lat: number;
  lon: number;
  state: string;
}

export type SafetyLevel = 'SAFE' | 'ADVISORY' | 'DANGER' | 'CYCLONE';

export interface SafetyScore {
  score: number;
  level: SafetyLevel;
  confidence: number;
  recommendation: string;
  reasoning: string[];
  safeReturnTime: string;
}

export interface Alert {
  id: string;
  type: 'WEATHER' | 'CYCLONE' | 'TIDE';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  message: {
    en: string;
    ta: string; // Tamil
    ml: string; // Malayalam
    te: string; // Telugu
    or: string; // Odia
    hi: string; // Hindi
  };
  timestamp: string;
}
