import React, { useState, useEffect, Component, ReactNode, ErrorInfo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, RefreshCw, AlertTriangle, LogOut } from 'lucide-react';
import Header from './components/Header';
import WeatherCard from './components/WeatherCard';
import SafetyScoreCard from './components/SafetyScoreCard';
import Map from './components/Map';
import AlertCenter from './components/AlertCenter';
import SOSButton from './components/SOSButton';
import LandingPage from './components/LandingPage';
import Auth from './components/Auth';
import HistoryView from './components/HistoryView';
import { FISHING_ZONES } from './constants';
import { WeatherData, SafetyScore, FishingZone } from './types';
import { calculateSafetyScore, generateMultilingualAlert } from './services/geminiService';
import { cn } from './lib/utils';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = { hasError: false };

  constructor(props: ErrorBoundaryProps) {
    super(props);
  }

  static getDerivedStateFromError(_: Error): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-ocean-950 p-6 text-center">
          <div className="glass p-8 rounded-3xl max-w-md">
            <AlertTriangle className="w-16 h-16 text-rose-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Something went wrong</h2>
            <p className="text-white/60 mb-6">We encountered an error while loading the safety system. Please try refreshing.</p>
            <button onClick={() => window.location.reload()} className="bg-ocean-500 px-6 py-3 rounded-xl font-bold">Refresh App</button>
          </div>
        </div>
      );
    }

    return (this as any).props.children;
  }
}

export default function App() {
  const [isStarted, setIsStarted] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('seasafe_token'));
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedZone, setSelectedZone] = useState<FishingZone>(FISHING_ZONES[0]);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [safetyScore, setSafetyScore] = useState<SafetyScore | null>(null);
  const [alerts, setAlerts] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial load from cache if available
    const cachedWeather = localStorage.getItem(`weather_${selectedZone.id}`);
    const cachedScore = localStorage.getItem(`score_${selectedZone.id}`);
    const cachedAlerts = localStorage.getItem(`alerts_${selectedZone.id}`);
    
    if (cachedWeather) setWeatherData(JSON.parse(cachedWeather));
    if (cachedScore) setSafetyScore(JSON.parse(cachedScore));
    if (cachedAlerts) setAlerts(JSON.parse(cachedAlerts));

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [selectedZone.id]);

  useEffect(() => {
    if (token) {
      fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Invalid token');
      })
      .then(data => setUser(data))
      .catch(() => {
        localStorage.removeItem('seasafe_token');
        setToken(null);
      });
    }
  }, [token]);

  const handleAuthSuccess = (newToken: string, newUser: any) => {
    localStorage.setItem('seasafe_token', newToken);
    setToken(newToken);
    setUser(newUser);
  };

  const handleLogout = () => {
    localStorage.removeItem('seasafe_token');
    setToken(null);
    setUser(null);
  };

  const fetchData = async (zone: FishingZone) => {
    if (isOffline) return; // Prevent fetching when offline, use cached state

    setIsLoading(true);
    try {
      const response = await fetch(`/api/weather?lat=${zone.lat}&lon=${zone.lon}`);
      const data = await response.json();
      setWeatherData(data);
      localStorage.setItem(`weather_${zone.id}`, JSON.stringify(data));

      const score = await calculateSafetyScore(data);
      setSafetyScore(score);
      localStorage.setItem(`score_${zone.id}`, JSON.stringify(score));

      const multilingualAlerts = await generateMultilingualAlert(score, zone.name);
      setAlerts(multilingualAlerts);
      localStorage.setItem(`alerts_${zone.id}`, JSON.stringify(multilingualAlerts));

      // Save safety report to backend
      if (token) {
        await fetch('/api/safety-reports', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            zoneId: zone.id,
            zoneName: zone.name,
            score: score.score,
            level: score.level,
            recommendation: score.recommendation,
            reasoning: score.reasoning,
            safeReturnTime: score.safeReturnTime,
            confidence: score.confidence
          })
        });
      }
    } catch (error) {
      console.error("Fetch error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isStarted && user) {
      fetchData(selectedZone);
    }
  }, [isStarted, selectedZone, user]);

  const handleZoneChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const zone = FISHING_ZONES.find(z => z.id === e.target.value);
    if (zone) setSelectedZone(zone);
  };

  const detectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        // Find nearest zone or use custom coordinates
        // For now, just show a message
        console.log("Location detected:", position.coords);
      });
    }
  };

  const handleSOS = async () => {
    if (!token) return;
    
    // Attempt to get location
    let lat = selectedZone.lat;
    let lon = selectedZone.lon;

    if (navigator.geolocation) {
      try {
        const position: any = await new Promise((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject);
        });
        lat = position.coords.latitude;
        lon = position.coords.longitude;
      } catch (e) {
        console.warn("Location access denied, using zone default");
      }
    }

    try {
      await fetch('/api/sos', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          lat,
          lon,
          zoneName: selectedZone.name,
          message: "Emergency SOS triggered from Fisherfolk Safety App"
        })
      });
    } catch (error) {
      console.error("SOS Signal failed:", error);
    }
  };

  if (!isStarted) {
    return <LandingPage onStart={() => setIsStarted(true)} />;
  }

  if (!user) {
    return <Auth onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-ocean-950 pb-24">
        <Header activeTab={activeTab} setActiveTab={setActiveTab} isOffline={isOffline} />
        
        <div className="max-w-7xl mx-auto px-6 pt-4 flex justify-end">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-white/40 hover:text-white text-xs font-bold transition-colors uppercase tracking-widest"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>

        <main className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-8">
            {/* Main Column */}
            <div className="flex flex-col gap-8">
              <div className="bg-white/5 border border-white/15 p-6 rounded-[24px] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-accent-blue" />
                  <h2 className="font-bold text-lg uppercase tracking-tight">Select Fishing Zone</h2>
                </div>
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <select 
                    value={selectedZone.id}
                    onChange={handleZoneChange}
                    className="flex-1 sm:w-64 bg-navy-dark border border-white/15 rounded-xl px-4 py-2.5 font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-accent-blue transition-all"
                  >
                    {FISHING_ZONES.map(zone => (
                      <option key={zone.id} value={zone.id} className="bg-navy-dark">{zone.name}, {zone.state}</option>
                    ))}
                  </select>
                  <button 
                    onClick={fetchData.bind(null, selectedZone)}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/15"
                  >
                    <RefreshCw className={cn("w-5 h-5", isLoading && "animate-spin")} />
                  </button>
                </div>
              </div>

              <AnimatePresence mode="wait">
                {activeTab === 'dashboard' && (
                  <motion.div
                    key="dashboard"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex flex-col gap-8"
                  >
                    {safetyScore && <SafetyScoreCard score={safetyScore} />}
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {weatherData && <WeatherCard data={weatherData} />}
                      <div className="bg-white/5 border border-white/15 p-6 rounded-[24px]">
                        <h3 className="font-bold mb-4 uppercase text-xs tracking-widest text-text-dim">Emergency Contacts</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between p-4 bg-navy-dark/50 rounded-xl border border-white/5">
                            <span className="text-sm font-bold">Coast Guard</span>
                            <a href="tel:1554" className="text-accent-blue font-black tracking-tighter">1554</a>
                          </div>
                          <div className="flex items-center justify-between p-4 bg-navy-dark/50 rounded-xl border border-white/5">
                            <span className="text-sm font-bold">Fisheries Dept</span>
                            <a href="tel:1800" className="text-accent-blue font-black tracking-tighter">1800-425-3534</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'map' && (
                  <motion.div
                    key="map"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                  >
                    <Map 
                      center={[selectedZone.lat, selectedZone.lon]} 
                      zones={FISHING_ZONES} 
                      safetyLevel={safetyScore?.level || 'SAFE'} 
                    />
                  </motion.div>
                )}

                {activeTab === 'alerts' && (
                  <motion.div
                    key="alerts"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="h-[600px]"
                  >
                    {alerts && <AlertCenter alerts={alerts} />}
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                  >
                    <HistoryView token={token} />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Side Column */}
            <div className="flex flex-col gap-8">
              <div className="h-[280px] rounded-[24px] overflow-hidden border border-white/15 relative">
                <Map 
                  center={[selectedZone.lat, selectedZone.lon]} 
                  zones={FISHING_ZONES} 
                  safetyLevel={safetyScore?.level || 'SAFE'} 
                />
                <div className="absolute bottom-3 left-3 z-20 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border border-white/10">
                  Zone: {selectedZone.id.toUpperCase()}-SEGMENT
                </div>
              </div>

              <div className="flex-1">
                {alerts && <AlertCenter alerts={alerts} />}
              </div>

              <SOSButton onSOS={handleSOS} />
            </div>
          </div>
        </main>
      </div>
    </ErrorBoundary>
  );
}
