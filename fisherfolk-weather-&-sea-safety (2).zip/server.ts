import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret-for-dev";

// Auth Middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ error: "Access denied" });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ error: "Invalid token" });
    req.user = user;
    next();
  });
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- PUBLIC API ROUTES ---

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Auth: Register
  app.post("/api/auth/register", async (req, res) => {
    const { email, password, name, phone } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await prisma.user.create({
        data: {
          email,
          password: hashedPassword,
          name,
          phoneNumber: phone,
          role: 'FISHERMAN'
        }
      });
      const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
      res.json({ token, user: { id: user.id, name: user.name, role: user.role } });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ error: "User already exists or invalid data" });
    }
  });

  // Auth: Login
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) return res.status(404).json({ error: "User not found" });

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) return res.status(401).json({ error: "Invalid password" });

      const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
      res.json({ token, user: { id: user.id, name: user.name, role: user.role } });
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Marine Weather Proxy (Open-Meteo)
  app.get("/api/weather", async (req, res) => {
    const { lat, lon } = req.query;
    if (!lat || !lon) {
      return res.status(400).json({ error: "Latitude and Longitude are required" });
    }

    try {
      const url = `https://marine-api.open-meteo.com/v1/marine?latitude=${lat}&longitude=${lon}&current=wave_height,wave_direction,wave_period,wind_wave_height&hourly=wave_height,wave_direction,wave_period&daily=wave_height_max,wave_direction_dominant,wave_period_max&timezone=auto`;
      const response = await fetch(url);
      const data = await response.json();
      
      const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility&hourly=temperature_2m,wind_speed_10m,visibility&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant&timezone=auto`;
      const weatherResponse = await fetch(weatherUrl);
      const weatherData = await weatherResponse.json();

      res.json({ marine: data, weather: weatherData });
    } catch (error) {
      console.error("Weather fetch error:", error);
      res.status(500).json({ error: "Failed to fetch weather data" });
    }
  });

  // --- PROTECTED API ROUTES ---

  // Get Current User Profile
  app.get("/api/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { id: true, email: true, name: true, role: true, phoneNumber: true }
      });
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user profile" });
    }
  });

  // Log SOS Signal
  app.post("/api/sos", authenticateToken, async (req: any, res) => {
    const { lat, lon, message, zoneName } = req.body;
    try {
      const signal = await prisma.sOSSignal.create({
        data: {
          userId: req.user.id,
          lat,
          lon,
          message,
          zoneName,
          status: 'PENDING'
        }
      });
      res.json(signal);
    } catch (error) {
      console.error("SOS Signal error:", error);
      res.status(500).json({ error: "Failed to log SOS signal" });
    }
  });

  // Get SOS History (For Admins/Coast Guard)
  app.get("/api/admin/sos", authenticateToken, async (req: any, res) => {
    if (req.user.role !== 'ADMIN' && req.user.role !== 'COAST_GUARD') {
      return res.status(403).json({ error: "Unauthorized" });
    }
    try {
      const signals = await prisma.sOSSignal.findMany({
        include: { user: { select: { name: true, phoneNumber: true } } },
        orderBy: { createdAt: 'desc' }
      });
      res.json(signals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch SOS signals" });
    }
  });

  // Save AI Safety Report
  app.post("/api/safety-reports", authenticateToken, async (req: any, res) => {
    const { zoneId, zoneName, score, level, recommendation, reasoning, safeReturnTime, confidence } = req.body;
    try {
      const report = await prisma.safetyReport.create({
        data: {
          userId: req.user.id,
          zoneId,
          zoneName,
          score,
          level,
          recommendation,
          reasoning,
          safeReturnTime,
          confidence
        }
      });
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to save safety report" });
    }
  });

  // Get Safety History
  app.get("/api/safety-reports", authenticateToken, async (req: any, res) => {
    try {
      const reports = await prisma.safetyReport.findMany({
        where: { userId: req.user.id },
        orderBy: { createdAt: 'desc' },
        take: 10
      });
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch safety history" });
    }
  });

  // --- VITE / STATIC SERVING ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
